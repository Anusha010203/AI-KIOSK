-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.5.19


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema pharmacat
--

CREATE DATABASE IF NOT EXISTS pharmacat;
USE pharmacat;

--
-- Definition of table `booking`
--

DROP TABLE IF EXISTS `booking`;
CREATE TABLE `booking` (
  `Record_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Doctor_ID` int(11) DEFAULT NULL,
  `Patient_ID` int(11) DEFAULT NULL,
  `Appointment_Time` time DEFAULT NULL,
  `Status` int(11) DEFAULT NULL,
  `hosp` varchar(115) DEFAULT NULL,
  `diag` longtext,
  PRIMARY KEY (`Record_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `booking`
--

/*!40000 ALTER TABLE `booking` DISABLE KEYS */;
/*!40000 ALTER TABLE `booking` ENABLE KEYS */;


--
-- Definition of table `doctor_fields`
--

DROP TABLE IF EXISTS `doctor_fields`;
CREATE TABLE `doctor_fields` (
  `Field_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Disease` varchar(255) DEFAULT NULL,
  `Specialisation` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Field_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctor_fields`
--

/*!40000 ALTER TABLE `doctor_fields` DISABLE KEYS */;
INSERT INTO `doctor_fields` (`Field_ID`,`Disease`,`Specialisation`) VALUES 
 (1,'Fungal infection','Dermatologist'),
 (2,'Allergy','Allergist/Immunologists'),
 (3,'GERD','Gastroenterologist'),
 (4,'Acne','Dermatologist'),
 (5,'hepatitis A','Hepatologist'),
 (6,'hepatitis B','Hepatologist'),
 (7,'hepatitis C','Hepatologist'),
 (8,'hepatitis D','Hepatologist'),
 (9,'hepatitis E','Hepatologist'),
 (10,'Chronic cholestasis','Gastroenterologist'),
 (11,'Drug Reaction','Pharmacologist'),
 (12,'Peptic ulcer disease','Gastroenterologist'),
 (13,'AIDS','HIV Specialist'),
 (14,'Diabetes','Endocrinologist'),
 (15,'Gastroenteritis','Gastroenterologist'),
 (16,'Bronchial Asthma','Asthma Specialist'),
 (17,'Hypertension','Cardiologist'),
 (18,'Migraine','Neurologist'),
 (19,'Cervical spondylosis','Otolaryngologist'),
 (20,'Paralysis (brain hemorrhage)','Paralysis Doctor'),
 (21,'Jaundice','Gastroenterologist'),
 (22,'Malaria','General Physician'),
 (23,'Chicken pox','General Physician'),
 (24,'Dengue','Microbiologist'),
 (25,'Typhoid','General Physician');
INSERT INTO `doctor_fields` (`Field_ID`,`Disease`,`Specialisation`) VALUES 
 (26,'Alcoholic hepatitis','Gastroenterologist'),
 (27,'Tuberculosis','Pulmonologists'),
 (28,'Common Cold','Otolaryngologist'),
 (29,'Pneumonia','Pediatric'),
 (30,'Dimorphic hemmorhoids(piles)','Proctologist'),
 (31,'Heart attack','Cardiologist'),
 (32,'Varicose veins','Endocrinologist'),
 (33,'Hypothyroidism','Endocrinologist'),
 (34,'Hyperthyroidism','Endocrinologist'),
 (35,'Hypoglycemia','Endocrinologist'),
 (36,'Osteoarthristis','Orthopedist'),
 (37,'Arthritis','Orthopedist'),
 (38,'(vertigo) Paroymsal Positional Vertigo','ENT Specialist'),
 (39,'Urinary tract infection','Urologist'),
 (40,'Psoriasis','Physician'),
 (41,'Impetigo','Expert Physician');
/*!40000 ALTER TABLE `doctor_fields` ENABLE KEYS */;


--
-- Definition of table `doctors`
--

DROP TABLE IF EXISTS `doctors`;
CREATE TABLE `doctors` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Username` varchar(255) DEFAULT NULL,
  `Password` varchar(255) DEFAULT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `Full_Name` varchar(255) DEFAULT NULL,
  `Registration_Number` varchar(255) DEFAULT NULL,
  `Contact_Number` bigint(13) DEFAULT NULL,
  `Hospital_Name` varchar(255) DEFAULT NULL,
  `Specialization` varchar(255) DEFAULT NULL,
  `Address` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctors`
--

/*!40000 ALTER TABLE `doctors` DISABLE KEYS */;
INSERT INTO `doctors` (`ID`,`Username`,`Password`,`Email`,`Full_Name`,`Registration_Number`,`Contact_Number`,`Hospital_Name`,`Specialization`,`Address`) VALUES 
 (1,'eswar','$2b$12$IPrhjJCiok2nPUW26HJJ4uNVOCnKdodZnekugZ3ktg.JvFeLkNRim','eswaranmindsoft@gmail.com','eswar','1234',9902752525,'Default Hospital','Cardiologist','bangalore');
/*!40000 ALTER TABLE `doctors` ENABLE KEYS */;


--
-- Definition of table `hospital`
--

DROP TABLE IF EXISTS `hospital`;
CREATE TABLE `hospital` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `hname` varchar(145) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hospital`
--

/*!40000 ALTER TABLE `hospital` DISABLE KEYS */;
INSERT INTO `hospital` (`id`,`hname`) VALUES 
 (1,'Apollo Spectra Hospital'),
 (2,'St.Johans Hospital'),
 (3,'Acura Speciality Hospital'),
 (4,'Vaastalya Hospital'),
 (5,'Apollo Cradle & Children Hospital'),
 (6,'Apollo Medical Center'),
 (7,'Sri Lakshmi Global Hospital'),
 (8,'Aparna Hospital'),
 (9,'CGHS Wellness Center'),
 (10,'Marvel Multispeciality Hospital'),
 (11,'Kaveri speciality Hospital'),
 (12,'Aadhya Healthcare Pvt Ltd'),
 (13,'Varalakshmi Hospital'),
 (14,'Ayu Health Hospitals'),
 (15,'Jindalnagar Rural Charitable Hospitals'),
 (16,'Shraddha Healthcare & Nusrsing'),
 (17,'Dr. Agarwals Eye Hospital'),
 (18,'Ganga Multi Speciality Clinic'),
 (19,'Dr Abraham Koshy');
/*!40000 ALTER TABLE `hospital` ENABLE KEYS */;


--
-- Definition of table `medicine`
--

DROP TABLE IF EXISTS `medicine`;
CREATE TABLE `medicine` (
  `Medicine_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Disease` varchar(255) DEFAULT NULL,
  `Name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Medicine_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `medicine`
--

/*!40000 ALTER TABLE `medicine` DISABLE KEYS */;
INSERT INTO `medicine` (`Medicine_ID`,`Disease`,`Name`) VALUES 
 (1,'Fungal infection','Seborrheic Dermatitis'),
 (2,'Allergy','Aripiprazole'),
 (3,'GERD','Kapidex'),
 (4,'Chronic cholestasis','amoxicillin'),
 (5,'Drug Reaction','Percocet'),
 (6,'Peptic ulcer diseae','clarithromycin'),
 (7,'AIDS','Atripla'),
 (8,'Diabetes','Lyrica'),
 (9,'Gastroenteritis','Zofran'),
 (10,'Bronchial Asthma','Prednisone'),
 (11,'Hypertension','Methylphenidate'),
 (12,'Migraine','Topiramate'),
 (13,'Cervical spondylosis','Gabapentin'),
 (14,'Paralysis (brain hemorrhage)','Belsomra'),
 (15,'Jaundice','Ledipasvir / sofosbuvir'),
 (16,'Malaria','Malarone'),
 (17,'Chicken pox','Tri-Linyah'),
 (18,'Dengue','Acetaminophen'),
 (19,'Typhoid','Amoxicillin / clavulanate'),
 (20,'hepatitis A','Dimenhydrinate'),
 (21,'hepatitis B','Tenofovir'),
 (22,'hepatitis C','Ledipasvir / sofosbuvir'),
 (23,'hepatitis D','Hydromorphone'),
 (24,'hepatitis E','acetaminophen'),
 (25,'Alcoholic hepatitis','Corticosteroids'),
 (26,'Tuberculosis','Isoniazid'),
 (27,'Common Cold','Benzonatate');
INSERT INTO `medicine` (`Medicine_ID`,`Disease`,`Name`) VALUES 
 (28,'Pneumonia','Loratadine'),
 (29,'Dimorphic hemmorhoids(piles)','Proctofoam'),
 (30,'Heart attack','Venlafaxine'),
 (31,'Varicose veins','Gabapentin'),
 (32,'Hypothyroidism','Ziprasidone'),
 (33,'Hyperthyroidism','Adderall XR'),
 (34,'Hypoglycemia','Lurasidone'),
 (35,'Osteoarthristis','Corticosteroids'),
 (36,'Arthritis','Etanercept'),
 (37,'(vertigo) Paroymsal Positional Vertigo','Effexor'),
 (38,'Acne','Ethinyl estradiol'),
 (39,'Urinary tract infection','Trimethoprim'),
 (40,'Psoriasis','Halobetasol'),
 (41,'Impetigo','Keflex');
/*!40000 ALTER TABLE `medicine` ENABLE KEYS */;


--
-- Definition of table `symptoms`
--

DROP TABLE IF EXISTS `symptoms`;
CREATE TABLE `symptoms` (
  `Symptom_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Symptom_Name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Symptom_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=91 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `symptoms`
--

/*!40000 ALTER TABLE `symptoms` DISABLE KEYS */;
INSERT INTO `symptoms` (`Symptom_ID`,`Symptom_Name`) VALUES 
 (1,'back_pain'),
 (2,'constipation'),
 (3,'abdominal_pain'),
 (4,'diarrhoea'),
 (5,'mild_fever'),
 (6,'yellow_urine'),
 (7,'yellowing_of_eyes'),
 (8,'acute_liver_failure'),
 (9,'fluid_overload'),
 (10,'swelling_of_stomach'),
 (11,'swelled_lymph_nodes'),
 (12,'malaise'),
 (13,'blurred_and_distorted_vision'),
 (14,'phlegm'),
 (15,'throat_irritation'),
 (16,'redness_of_eyes'),
 (17,'sinus_pressure'),
 (18,'runny_nose'),
 (19,'congestion'),
 (20,'chest_pain'),
 (21,'weakness_in_limbs'),
 (22,'fast_heart_rate'),
 (23,'pain_during_bowel_movements'),
 (24,'pain_in_anal_region'),
 (25,'bloody_stool'),
 (26,'irritation_in_anus'),
 (27,'neck_pain'),
 (28,'dizziness'),
 (29,'cramps'),
 (30,'bruising'),
 (31,'obesity'),
 (32,'swollen_legs'),
 (33,'swollen_blood_vessels'),
 (34,'puffy_face_and_eyes'),
 (35,'enlarged_thyroid'),
 (36,'brittle_nails'),
 (37,'slurred_speech'),
 (38,'knee_pain'),
 (39,'hip_joint_pain'),
 (40,'muscle_weakness'),
 (41,'stiff_neck');
INSERT INTO `symptoms` (`Symptom_ID`,`Symptom_Name`) VALUES 
 (42,'swelling_joints'),
 (43,'movement_stiffness'),
 (44,'spinning_movements'),
 (45,'loss_of_balance'),
 (46,'unsteadiness'),
 (47,'weakness_of_one_body_side'),
 (48,'loss_of_smell'),
 (49,'bladder_discomfort'),
 (50,'foul_smell_of_urine'),
 (51,'continuous_feel_of_urine'),
 (52,'passage_of_gases'),
 (53,'internal_itching'),
 (54,'toxic_look_(typhos)'),
 (55,'depression'),
 (56,'irritability'),
 (57,'muscle_pain'),
 (58,'altered_sensorium'),
 (59,'red_spots_over_body'),
 (60,'belly_pain'),
 (61,'abnormal_menstruation'),
 (62,'dischromic_patches'),
 (63,'watering_from_eyes'),
 (64,'increased_appetite'),
 (65,'polyuria'),
 (66,'family_history'),
 (67,'mucoid_sputum'),
 (68,'rusty_sputum'),
 (69,'lack_of_concentration'),
 (70,'visual_disturbances'),
 (71,'receiving_blood_transfusion'),
 (72,'receiving_unsterile_injections'),
 (73,'coma'),
 (74,'stomach_bleeding'),
 (75,'distention_of_abdomen'),
 (76,'palpitations'),
 (77,'painful_walking'),
 (78,'pus_filled_pimples');
INSERT INTO `symptoms` (`Symptom_ID`,`Symptom_Name`) VALUES 
 (79,'blackheads'),
 (80,'scurring'),
 (81,'skin_peeling'),
 (82,'history_of_alcohol_consumption'),
 (83,'fluid_overload'),
 (84,'blood_in_sputum'),
 (85,'prominent_veins_on_calf'),
 (86,'silver_like_dusting'),
 (87,'small_dents_in_nails'),
 (88,'blister'),
 (89,'red_sore_around_nose'),
 (90,'yellow_crust_ooze');
/*!40000 ALTER TABLE `symptoms` ENABLE KEYS */;


--
-- Definition of table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Username` varchar(255) DEFAULT NULL,
  `Password` varchar(255) DEFAULT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `Full_Name` varchar(255) DEFAULT NULL,
  `Address` varchar(255) DEFAULT NULL,
  `Blood_Group` varchar(255) DEFAULT NULL,
  `Age` int(11) DEFAULT NULL,
  `API_Token` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`ID`,`Username`,`Password`,`Email`,`Full_Name`,`Address`,`Blood_Group`,`Age`,`API_Token`) VALUES 
 (1,'lavanya','$2b$12$h/WTz4Eq9GmcCwJ7Yl5rKOPZfYAt1phJPntKg17Efl33GJ/9pf/0C','lavanya@gmail.com','lavanya','bangalore','O+',21,'bGF2YW55YSh+KWxhdmFueWE=');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;




/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
